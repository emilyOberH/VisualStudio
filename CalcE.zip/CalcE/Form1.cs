﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double result;
        double firstdigit;
        string Operator;
        bool isOperator = false;

        private void button36_Click(object sender, EventArgs e)//
        {
            if (textBox.Text == "0" || isOperator)
                textBox.Clear();
            isOperator = false;
            Button button = (Button)sender;
            if (button.Text==".")
            {
                if (!textBox.Text.Contains("."))
                {
                    textBox.Text += button.Text;
                }
                
            }
            else
            {
                textBox.Text += button.Text;
            }
            //textBox.Text = button.Text;
        }

        private void button35_Click(object sender, EventArgs e)//
        {
            int index = textBox.Text.Length;
            index--;
            textBox.Text = textBox.Text.Remove(index);
            if (textBox.Text == "")
            {
                textBox.Text = "0";
            }
        }

        private void button40_Click(object sender, EventArgs e)
        {
            textBox.Text = "0";
        }

        private void button30_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = result * -1;
            textBox.Text = result.ToString();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            firstdigit = double.Parse(textBox.Text);
            Button optr = (Button)sender;
            Operator = optr.Text;
            isOperator = true;
        }

        private void button26_Click(object sender, EventArgs e)
        {
            switch (Operator)
            {
                case "+":
                    textBox.Text = (firstdigit + double.Parse(textBox.Text)).ToString();
                    //textBox.Text = "+";
                    break;
                case "-":
                    textBox.Text = (firstdigit - double.Parse(textBox.Text)).ToString();
                    //textBox.Text = "-";
                    break;
                case "*":
                    textBox.Text = (firstdigit * double.Parse(textBox.Text)).ToString();
                    //textBox.Text = "*";
                    break;
                case "/":
                    textBox.Text = (firstdigit / double.Parse(textBox.Text)).ToString();
                    //textBox.Text = "/";
                    break;
                case "MOD":
                    textBox.Text = (firstdigit % double.Parse(textBox.Text)).ToString();
                    //textBox.Text = "/";
                    break;
                default:
                    //textBox.Text = "test";
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Log10(result);
            textBox.Text = result.ToString();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Sqrt(result);
            textBox.Text = result.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Sinh(result);
            textBox.Text = result.ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Sin(result);
            textBox.Text = result.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Cosh(result);
            textBox.Text = result.ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Cos(result);
            textBox.Text = result.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Tanh(result);
            textBox.Text = result.ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Tan(result);
            textBox.Text = result.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Exp(result);
            textBox.Text = result.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            result = Math.PI;
            textBox.Text = result.ToString();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = result*result;
            textBox.Text = result.ToString();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = result * result * result;
            textBox.Text = result.ToString();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = 1/result;
            textBox.Text = result.ToString();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            firstdigit = double.Parse(textBox.Text);
            Button optr = (Button)sender;
            Operator = optr.Text;
            isOperator = true;

        }

        private void button19_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Log(result);
            textBox.Text = result.ToString();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = result/100;
            textBox.Text = result.ToString();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Ceiling(result);
            textBox.Text = result.ToString();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox.Text);
            result = Math.Floor(result);
            textBox.Text = result.ToString();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            int top = 50;
            int left = 100;

            int k = 0;
            for (int i = 0; i < 8; i++)
            {
                Button a = new Button();
                for (int j = 0; j < 5; j++)
                
                {
                    int num = j + k + 1;

                    Button b = new Button();
                    b.Location = new Point(top, left);
                    b.Name = "button"+(j + k + 1).ToString();
                    this.Controls.Add(b);

                    b.Padding = new Padding(3);
                    b.Width = 70;
                    b.Height = 50;
                    left += b.Height + 10;

                    switch (num)
                    {   //first col
                        case 1:
                            b.Text = "OFF";
                            b.Click += new EventHandler(button1_Click);
                            break;
                        case 2:
                            b.Text = "Sinh";
                            b.Click += new EventHandler(button2_Click);
                            break;
                        case 3:
                            b.Text = "Cosh";
                            b.Click += new EventHandler(button3_Click);
                            break;
                        case 4:
                            b.Text = "Tanh";
                            b.Click += new EventHandler(button4_Click);
                            break;
                        case 5:
                            b.Text = "EXP";
                            b.Click += new EventHandler(button5_Click);
                            break;
                        //second col
                        case 6:
                            b.Text = "LOG";
                            b.Click += new EventHandler(button10_Click);
                            break;
                        case 7:
                            b.Text = "Sin";
                            b.Click += new EventHandler(button9_Click);
                            break;
                        case 8:
                            b.Text = "Cos";
                            b.Click += new EventHandler(button8_Click);
                            break;
                        case 9:
                            b.Text = "Tan";
                            b.Click += new EventHandler(button7_Click);
                            break;
                        case 10:
                            b.Text = "PI";
                            b.Click += new EventHandler(button6_Click);
                            break;
                        //third col
                        case 11:
                            b.Text = "SQRT";
                            b.Click += new EventHandler(button20_Click);
                            break;
                        case 12:
                            b.Text = "X^2";
                            b.Click += new EventHandler(button14_Click);
                            break;
                        case 13:
                            b.Text = "X^3";
                            b.Click += new EventHandler(button13_Click);
                            break;
                        case 14:
                            b.Text = "1/x";
                            b.Click += new EventHandler(button12_Click);
                            break;
                        case 15:
                            b.Text = "MOD";
                            b.Click += new EventHandler(button11_Click);
                            break;
                        //fourth col
                        case 17:
                            b.Text = "Ln X";
                            b.Click += new EventHandler(button19_Click);
                            break;
                        case 18:
                            b.Text = "%";
                            b.Click += new EventHandler(button18_Click);
                            break;
                        case 19:
                            b.Text = "Ciel";
                            b.Click += new EventHandler(button17_Click);
                            break;
                        case 20:
                            b.Text = "Floor";
                            b.Click += new EventHandler(button16_Click);
                            break;
                        //fifth col
                        case 21:
                            b.Text = "CE";
                            b.Click += new EventHandler(button40_Click);
                            break;
                        case 22:
                            b.Text = "7";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        case 23:
                            b.Text = "4";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        case 24:
                            b.Text = "1";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        case 25:
                            b.Text = "0";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        //sixth col
                        case 26:
                            b.Text = "DEL";
                            b.Click += new EventHandler(button35_Click);
                            break;
                        case 27:
                            b.Text = "8";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        case 28:
                            b.Text = "5";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        case 29:
                            b.Text = "2";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        case 30:
                            b.Text = ".";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        //seventh col
                        case 31:
                            b.Text = "±";
                            b.Click += new EventHandler(button30_Click);
                            break;
                        case 32:
                            b.Text = "9";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        case 33:
                            b.Text = "6";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        case 34:
                            b.Text = "3";
                            b.Click += new EventHandler(button36_Click);
                            break;
                        case 35:
                            b.Text = "=";
                            b.Click += new EventHandler(button26_Click);
                            break;
                        //eighth col
                        case 36:
                            b.Text = "*";
                            b.Click += new EventHandler(button25_Click);
                            break;
                        case 37:
                            b.Text = "/";
                            b.Click += new EventHandler(button25_Click);
                            break;
                        case 38:
                            b.Text = "-";
                            b.Click += new EventHandler(button25_Click);
                            break;
                        case 39:
                            b.Text = "+";
                            b.Click += new EventHandler(button25_Click);
                            break;


                        default:
                            Console.WriteLine("Default case");
                            break;
                    }

                }
                k+=5;
                left = 100;

               top += a.Height + 60;
            }
        }
    }
}

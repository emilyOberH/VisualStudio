﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz_1
{
    public partial class Form1 : Form
    {
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;

        public Form1()
        {
            InitializeComponent();

            askQuestion(questionNumber);

            totalQuestions = 6;
        }

        

        private void askQuestion(int qnum)
        {
            /*checkBox5.Visible = true;
            checkBox5.Enabled = true;
            checkBox6.Visible = true;
            checkBox6.Enabled = true;
            checkBox7.Visible = true;
            checkBox7.Enabled = true;
            checkBox8.Visible = true;
            checkBox8.Enabled = true;
            radioButton9.Visible = true;
            radioButton9.Enabled = true;
            radioButton10.Visible = true;
            radioButton10.Enabled = true;
            radioButton11.Visible = true;
            radioButton11.Enabled = true;
            radioButton12.Visible = true;
            radioButton12.Enabled = true;
            button1.Visible = true;
            button1.Enabled = true;
            button2.Visible = true;
            button2.Enabled = true;
            button3.Visible = true;
            button3.Enabled = true;
            button4.Visible = true;
            button4.Enabled = true;*/

            checkBox5.Checked = false;
            checkBox6.Checked = false;
            checkBox7.Checked = false;
            checkBox8.Checked = false;
            radioButton9.Checked = false;
            radioButton10.Checked = false;
            radioButton11.Checked = false;
            radioButton12.Checked = false;


            switch (qnum)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.question_mark_PNG128;
                    lblQuestion.Text = "On what river is Poland's capital, Warsaw?";
                    button1.Text = "Vistula";
                    button2.Text = "Warta";
                    button3.Text = "Oder";
                    button4.Text = "Pilica";
                    button1.Visible = false;
                    button1.Enabled = false;
                    button2.Visible = false;
                    button2.Enabled = false;
                    button3.Visible = false;
                    button3.Enabled = false;
                    button4.Visible = false;
                    button4.Enabled = false;

                    radioButton9.Visible = false;
                    radioButton9.Enabled = false;
                    radioButton10.Visible = false;
                    radioButton10.Enabled = false;
                    radioButton11.Visible = false;
                    radioButton11.Enabled = false;
                    radioButton12.Visible = false;
                    radioButton12.Enabled = false;

                    checkBox5.Visible = true;
                    checkBox5.Enabled = true;
                    checkBox6.Visible = true;
                    checkBox6.Enabled = true;
                    checkBox7.Visible = true;
                    checkBox7.Enabled = true;
                    checkBox8.Visible = true;
                    checkBox8.Enabled = true;

                    checkBox5.Text = "Vistula";
                    checkBox6.Text = "Warta";
                    checkBox7.Text = "Oder";
                    checkBox8.Text = "Pilica";

                    correctAnswer = 5; //1
                    break;
                case 2:
                    pictureBox1.Image = Properties.Resources.question_mark_PNG128;
                    lblQuestion.Text = "What does the name Lodz mean in English?";
                    button1.Text = "River";
                    button2.Text = "Gate";
                    button3.Text = "Field";
                    button4.Text = "Boat";
                    button1.Visible = true;
                    button1.Enabled = true;
                    button2.Visible = true;
                    button2.Enabled = true;
                    button3.Visible = true;
                    button3.Enabled = true;
                    button4.Visible = true;
                    button4.Enabled = true;

                    checkBox5.Visible = false;
                    checkBox5.Enabled = false;
                    checkBox6.Visible = false;
                    checkBox6.Enabled = false;
                    checkBox7.Visible = false;
                    checkBox7.Enabled = false;
                    checkBox8.Visible = false;
                    checkBox8.Enabled = false;

                    /*checkBox5.Text = "River";
                    checkBox6.Text = "Gate";
                    checkBox7.Text = "Field";
                    checkBox8.Text = "Boat";*/

                    correctAnswer = 4;  //4
                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.question_mark_PNG128;
                    lblQuestion.Text = "What is the biggest natural desert in Poland?";
                    /*button1.Text = "Accona Desert";
                    button2.Text = "Bledow Desert";
                    button3.Text = "Tabernas Desert";
                    button4.Text = "Oleshky Sands";

                    checkBox5.Text = "Accona Desert";
                    checkBox6.Text = "Bledow Desert";
                    checkBox7.Text = "Tabernas Desert";
                    checkBox8.Text = "Oleshky Sands";*/
                    button1.Visible = false;
                    button1.Enabled = false;
                    button2.Visible = false;
                    button2.Enabled = false;
                    button3.Visible = false;
                    button3.Enabled = false;
                    button4.Visible = false;
                    button4.Enabled = false;

                    radioButton9.Visible = true;
                    radioButton9.Enabled = true;
                    radioButton10.Visible = true;
                    radioButton10.Enabled = true;
                    radioButton11.Visible = true;
                    radioButton11.Enabled = true;
                    radioButton12.Visible = true;
                    radioButton12.Enabled = true;

                    radioButton9.Text = "Accona Desert";
                    radioButton10.Text = "Bledow Desert";
                    radioButton11.Text = "Tabernas Desert";
                    radioButton12.Text = "Oleshky Sands";

                    correctAnswer = 10;  //2
                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.question_mark_PNG128;
                    lblQuestion.Text = "What is the name of the biggest Polish island?";
                    radioButton9.Text = "Ostrow Tumski Island";
                    radioButton10.Text = "Wielki Krzek Island";
                    radioButton11.Text = "Usedom Island";
                    radioButton12.Text = "Wolin Island";

                    /*checkBox5.Text = "Ostrow Tumski Island";
                    checkBox6.Text = "Wielki Krzek Island";
                    checkBox7.Text = "Usedom Island";
                    checkBox8.Text = "Wolin Island";*/

                    correctAnswer = 8;  //4
                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.question_mark_PNG128;
                    lblQuestion.Text = "TWhat year did Lodz become a city?";
                    radioButton9.Text = "1210";
                    radioButton10.Text = "1719";
                    radioButton11.Text = "1423";
                    radioButton12.Text = "825";

                    /*checkBox5.Text = "1210";
                    checkBox6.Text = "1719";
                    checkBox7.Text = "1423";
                    checkBox8.Text = "825";*/

                    correctAnswer = 7; //3
                    break;
                case 6:
                    pictureBox1.Image = Properties.Resources.question_mark_PNG128;
                    lblQuestion.Text = "What is the name of the deepest lake in Poland?";
                    radioButton9.Text = "Lake Hancza";
                    radioButton10.Text = "Lake Jamno";
                    radioButton11.Text = "Lake Orzysz";
                    radioButton12.Text = "Lake Wigry";

                    /*checkBox5.Text = "Lake Hancza";
                    checkBox6.Text = "Lake Jamno";
                    checkBox7.Text = "Lake Orzysz";
                    checkBox8.Text = "Lake Wigry";*/

                    correctAnswer = 5;  //1
                    break;
            }

        }

        private void CheckAnswerEvent(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;
            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if (buttonTag == correctAnswer)
            {
                score++;
            }

            if(questionNumber == totalQuestions)
            {
                percentage = (int)Math.Round((double)(score*100)/totalQuestions);
                MessageBox.Show(
                    "Quiz Ended."+Environment.NewLine+"You have answered "+score+" questions correctly."+Environment.NewLine+
                    "Your percentage is "+percentage+"% "+Environment.NewLine+
                    "Click OK to play again."
                    );
                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }

            questionNumber++;
            askQuestion(questionNumber);
        }

        private void checkCheckbox(object sender, EventArgs e)
        {
            var senderObject = (CheckBox)sender;
            int checkBoxTag = Convert.ToInt32(senderObject.Tag);

            if (checkBoxTag == correctAnswer)
            {
                score++;
            }

            if (questionNumber == totalQuestions)
            {
                percentage = (int)Math.Round((double)(score * 100) / totalQuestions);
                MessageBox.Show(
                    "Quiz Ended." + Environment.NewLine + "You have answered " + score + " questions correctly." + Environment.NewLine +
                    "Your percentage is " + percentage + "% " + Environment.NewLine +
                    "Click OK to play again."
                    );
                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }

            questionNumber++;
            askQuestion(questionNumber);
        }

        private void radioChecked(object sender, EventArgs e)
        {
            var senderObject = (RadioButton)sender;
            int radioBoxTag = Convert.ToInt32(senderObject.Tag);

            if (radioBoxTag == correctAnswer)
            {
                score++;
            }

            if (questionNumber == totalQuestions)
            {
                percentage = (int)Math.Round((double)(score * 100) / totalQuestions);
                MessageBox.Show(
                    "Quiz Ended." + Environment.NewLine + "You have answered " + score + " questions correctly." + Environment.NewLine +
                    "Your percentage is " + percentage + "% " + Environment.NewLine +
                    "Click OK to play again."
                    );
                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }

            questionNumber++;
            askQuestion(questionNumber);
        }
    }
}
